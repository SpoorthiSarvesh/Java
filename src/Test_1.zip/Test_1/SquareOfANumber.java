package Test_1;

public class SquareOfANumber {
    public static void main(String[] args) {
        int i=8;
        //for(i=4;i<=10;i++)

            System.out.println("The Square of number  " + i +" is " + i*i);
        }

}
